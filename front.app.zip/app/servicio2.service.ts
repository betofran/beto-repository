import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class Servicio2Service {
  url = "http://localhost:9000";

  constructor(private http: HttpClient) { }

  get(){
    console.log("2");
    return this.http.get(this.url + "/2")
  }
}
