import { Component, OnInit } from '@angular/core';
import { Servicio1Service } from '../servicio1.service';

@Component({
  selector: 'app-componente1',
  templateUrl: './componente1.component.html',
  styleUrls: ['./componente1.component.css']
})
export class Componente1Component implements OnInit {

  data: any;

  constructor(private servicio: Servicio1Service) { }

  ngOnInit() {
    this.servicio.get().subscribe(
      (data: string) => this.data = data
    );
    
  }

}
