import { Component, OnInit } from '@angular/core';
import { Servicio2Service } from '../servicio2.service';

@Component({
  selector: 'app-componente2',
  templateUrl: './componente2.component.html',
  styleUrls: ['./componente2.component.css']
})
export class Componente2Component implements OnInit {

  data: any;

  constructor(private servicio: Servicio2Service) { }

  ngOnInit() {
    this.servicio.get().subscribe(
      (data: string) => this.data = data
    );
    
  }

}
