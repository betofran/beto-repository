import { Component, OnInit } from '@angular/core';
import { Servicio3Service } from '../servicio3.service';

@Component({
  selector: 'app-componente3',
  templateUrl: './componente3.component.html',
  styleUrls: ['./componente3.component.css']
})
export class Componente3Component implements OnInit {

  data: any;

  constructor(private servicio: Servicio3Service) { }

  ngOnInit() {
    this.servicio.get().subscribe(
      (data: string) => this.data = data
    );
    
  }

}
